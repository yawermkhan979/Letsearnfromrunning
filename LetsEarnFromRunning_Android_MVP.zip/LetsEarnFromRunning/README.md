# Let's Earn from Running — Android MVP

A starter Android Studio project for a walking-rewards app.

## Included in this first prototype
- Native Android app using Kotlin and Jetpack Compose.
- Uses the phone's `TYPE_STEP_DETECTOR` sensor.
- Requests Android Activity Recognition permission.
- Stores today's step count and demo coin balance locally.
- Resets the daily count when a new date is detected.
- Illustrative reward rule: 1 demo coin per 100 steps, capped at 100 coins/day.
- AdMob banner wired to Google's official test app/ad IDs.

## Important limitations — not ready for public release
1. **Foreground-only step tracking:** this prototype counts steps while the app is open. It does not yet provide reliable background tracking.
2. **Demo coins only:** coins are local demo points, not money. No UPI payouts are implemented.
3. **No secure account/backend:** local balances can be modified or lost if app data is cleared or the app is reinstalled.
4. **AdMob test IDs:** replace them with your own AdMob app ID and ad unit ID after account setup. Never click your own live ads.
5. **No production anti-fraud:** do not promise cash rewards until server-side verification, a transaction ledger, payout controls and fraud monitoring exist.

## Open and run
1. Install Android Studio (stable version) and Android SDK Platform 35.
2. Extract this project.
3. In Android Studio, choose **Open** and select this folder.
4. Allow Gradle sync to finish.
5. Connect an Android phone with developer options and USB debugging enabled, or start an emulator.
6. Press **Run**.
7. Grant Activity Recognition permission when prompted.

A physical phone with a step-detector sensor is needed for real step events. Some emulators do not provide this sensor.

## Before publishing to Google Play
- Choose and register the final developer account.
- Create a privacy policy and public support contact.
- Complete Data safety, app access, ads, and any health/fitness declarations accurately.
- Add account creation/deletion only when backend authentication is implemented.
- Replace test AdMob IDs with your own approved IDs.
- Build and sign an Android App Bundle (AAB).
- Complete required Play Console testing and review.
- Review current Google Play policies for health/fitness data and ads.

## Recommended next development milestone
Build a backend (e.g. Firebase Authentication + Cloud Functions + Firestore) with:
- server-authoritative step/reward ledger,
- daily earning limits,
- fraud/risk checks,
- admin console,
- payout request workflow,
- a compliant payout provider integration.

Do not store UPI PINs or ask users to share them. Payouts should be initiated by the backend through a provider-approved flow.
