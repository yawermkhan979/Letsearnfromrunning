package com.letsearn.running

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import androidx.compose.ui.viewinterop.AndroidView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val DAILY_GOAL = 5_000
private const val STEPS_PER_COIN = 100
private const val DAILY_COIN_CAP = 100

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var stepDetector: Sensor? = null
    private var onStep: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepDetector = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF16865B),
                    secondary = Color(0xFF5CB98B),
                    background = Color(0xFFF5F8F6)
                )
            ) {
                WalkEarnApp(
                    hasStepSensor = stepDetector != null,
                    onStepCallbackReady = { callback -> onStep = callback }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (stepDetector != null && hasActivityPermission()) {
            sensorManager.registerListener(this, stepDetector, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    private fun hasActivityPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) ==
            PackageManager.PERMISSION_GRANTED

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_STEP_DETECTOR) onStep?.invoke()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}

@Composable
private fun WalkEarnApp(
    hasStepSensor: Boolean,
    onStepCallbackReady: ((() -> Unit) -> Unit)
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("walk_earn", Context.MODE_PRIVATE) }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    var savedDate by remember { mutableStateOf(prefs.getString("date", today) ?: today) }
    var steps by remember { mutableIntStateOf(prefs.getInt("steps", 0)) }
    var totalCoins by remember { mutableIntStateOf(prefs.getInt("coins", 0)) }
    var dailyCoins by remember { mutableIntStateOf(prefs.getInt("daily_coins", 0)) }
    var permissionGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACTIVITY_RECOGNITION) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var showInfo by remember { mutableStateOf(false) }

    // Reset the daily counter when the app is opened on a new calendar day.
    LaunchedEffect(today) {
        if (savedDate != today) {
            savedDate = today
            steps = 0
            dailyCoins = 0
            prefs.edit().putString("date", today).putInt("steps", 0).putInt("daily_coins", 0).apply()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> permissionGranted = granted }

    fun recordStep() {
        steps += 1
        val eligibleCoins = minOf(steps / STEPS_PER_COIN, DAILY_COIN_CAP)
        val newlyEarned = (eligibleCoins - dailyCoins).coerceAtLeast(0)
        if (newlyEarned > 0) {
            dailyCoins += newlyEarned
            totalCoins += newlyEarned
        }
        prefs.edit()
            .putString("date", today)
            .putInt("steps", steps)
            .putInt("daily_coins", dailyCoins)
            .putInt("coins", totalCoins)
            .apply()
    }

    SideEffect { onStepCallbackReady { if (permissionGranted) recordStep() } }

    Scaffold(
        containerColor = Color(0xFFF5F8F6),
        bottomBar = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Advertisement", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                AdMobBanner()
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("LET'S EARN", style = MaterialTheme.typography.labelLarge, color = Color(0xFF16865B), fontWeight = FontWeight.Bold)
                    Text("from Running", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color(0xFF18352A))
                    Text("Move more. Build healthy habits.", color = Color.Gray)
                }
                Surface(shape = CircleShape, color = Color(0xFFE0F2E8), modifier = Modifier.size(54.dp)) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = Color(0xFF16865B), modifier = Modifier.padding(13.dp))
                }
            }

            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF16865B))) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TODAY'S STEPS", color = Color.White.copy(alpha = .85f), style = MaterialTheme.typography.labelLarge)
                    Text("%,d".format(steps), color = Color.White, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(
                        progress = { (steps.toFloat() / DAILY_GOAL).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(9.dp),
                        color = Color(0xFFFFD66B),
                        trackColor = Color.White.copy(alpha = .25f)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("${steps.coerceAtMost(DAILY_GOAL)} / $DAILY_GOAL step goal", color = Color.White)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Coins today", "$dailyCoins", Icons.Default.EmojiEvents, Modifier.weight(1f))
                StatCard("Total coins", "$totalCoins", Icons.Default.Payments, Modifier.weight(1f))
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("How rewards work", fontWeight = FontWeight.Bold)
                    Text("Earn 1 coin for every 100 steps, up to 100 coins per day.")
                    Text("Coins are demo points in this prototype. They are not cash and cannot yet be withdrawn.")
                    Text("Your step sensor is counted while this app is open.")
                }
            }

            if (!permissionGranted) {
                Button(
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            permissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
                        } else permissionGranted = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Allow activity / step access") }
            } else if (!hasStepSensor) {
                Text("This phone does not expose a step detector sensor. Step tracking is unavailable on this device.", color = MaterialTheme.colorScheme.error)
            } else {
                Text("Step tracking is active while this app is open.", color = Color(0xFF16865B))
            }

            OutlinedButton(onClick = { showInfo = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("About wallet & withdrawals")
            }
        }
    }

    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text("Wallet and UPI payouts") },
            text = { Text("UPI cash withdrawals are not enabled in this prototype. A secure backend, verified user accounts, a funded rewards pool, payout-provider onboarding, fraud checks and legal/policy review are required before real-money rewards can be offered.") },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Got it") } }
        )
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, contentDescription = null, tint = Color(0xFF16865B))
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(title, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AdMobBanner() {
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(50.dp),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                // Google's official test banner unit ID. Replace with your own before release.
                adUnitId = "ca-app-pub-3940256099942544/9214589741"
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
